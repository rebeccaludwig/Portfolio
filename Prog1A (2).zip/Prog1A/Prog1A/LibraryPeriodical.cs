﻿// Grading ID: D1474
// Program number: 1A
// Due date: Feb 15, 2017 
// Course section: 200-01
// Description: this class gets values for periodical type library items and provides info for sub classes

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public abstract class LibraryPeriodical : LibraryItem
    {
        private int _volume; // The periodical's volume
        private int _number; // The preiodical's number


        // Precondition: non null values as specified
        // Postcondition: values returned 
        public LibraryPeriodical(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod, string theCallNumber, int theVolume, int theNumber)
        : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            Volume = theVolume;
            Number = theNumber;
        }

        public int Volume
        {
            // Precondition:  None
            // Postcondition: The volume returned
            get
            {
                return _volume;
            }

            // Precondition:  >= 0
            // Postcondition: The voulme set to value
            set
            {
                if (value >= 0)
                    _volume = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Volume)}", value,
                        $"{nameof(Volume)} must be >= 0");
            }
        }

        public int Number
        {
            // Precondition:  None
            // Postcondition: The number returned
            get
            {
                return _number;
            }

            // Precondition:  >= 0
            // Postcondition: The number set to value
            set
            {
                if (value >= 0)
                    _number = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Number)}", value,
                        $"{nameof(Number)} must be >= 0");
            }
        }

        // Precondition:  None
        // Postcondition: A string is returned presenting the libary periodical's data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";

            return $"Periodical{NL}" + $"Volume: {Volume}{NL}" + $"Number: {Number}{NL}" + base.ToString();
        }

    }

}
