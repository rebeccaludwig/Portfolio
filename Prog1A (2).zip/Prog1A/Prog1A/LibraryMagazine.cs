﻿// Grading ID: D1474
// Program number: 1A
// Due date: Feb 15, 2017 
// Course section: 200-01
// Description: This class return info on magazine checked out from library and calulates any late fees


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    class LibraryMagazine : LibraryPeriodical
    {
        public const decimal DAILY_LATE_FEE = .25M; // daily late fee
        public const decimal MAX_FEE = 20.00M; // max fee

        // Preconditions: not null values meet requirements
        // Postconditions: values are returned
        public LibraryMagazine(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod, string theCallNumber, int theVolume, int theNumber)
        : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theVolume, theNumber)
        {
           
        }

        // Precondition:    Days late >= 0
        // Postcondition:   Late fee per day calulated and returned
        public override decimal CalcLateFee(int daysLate)
        {
            decimal totalFee = 0M; // holds fee

            if (daysLate < 0)
                throw new ArgumentOutOfRangeException($"{nameof(daysLate)}",
                        $"{nameof(daysLate)} must be >= 0");
            else
                totalFee = daysLate * DAILY_LATE_FEE;

            return Math.Min(totalFee, MAX_FEE);

        }

        // Precondition:  None
        // Postcondition: A string is returned presenting the libary movie's data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";

            return $"Library Magazine{NL}" + base.ToString();
        }
    }
}



