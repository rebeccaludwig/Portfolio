﻿// Grading ID: D1474
// Program number: 1A
// Due date: Feb 15, 2017 
// Course section: 200-01
// Description: this class gets info for library movies and calulates any late fees


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    class LibraryMovie
    {
        public class LibraryMovie : LibraryMediaItem
        {
            public enum MPAARatings { G, PG, PG13, R, NC17, U };    // Movie ratings

            public const decimal DVD_VHS_DAILY_LATE_FEE = 1.00M;    // DVD/VHS late fee 
            public const decimal BLURAY_DAILY_LATE_FEE = 1.50M;    // BluRay late fee 
            public const decimal MAX_FEE = 25.00M;                   // Max late fee

            private MediaType _medium;                          // The movie's medium

            private string _director;   // the movie's director

            // String names of ratings
            private string[] RatingTypes = { "G", "PG", "PG-13", "R", "NC-17", "U" };

            // Precondition: non null conditions
            // Postcondition: Movie initailized with values
            public LibraryMovie(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod, string theCallNumber, double theDuration, string theDirector, string theMedium, string theRating)
                : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theDuration)
            {
                Director = theDirector;
                Rating = theRating;
                Medium = theMedium;

            }

            public string Director
            {
                // Precondition:  None
                // Postcondition: The director returned
                get
                {
                    return _director;
                }

                // Precondition:  Not null
                // Postcondition: The director is set to value
                set
                {
                    // Since empty director is OK, just change null to empty string
                    _director = (value == null ? string.Empty : value.Trim());
                }
            }

            public MPAARatings Rating
            {
                // Precondition:  None
                // Postcondition: The rating returned
                get;

                // Precondition:  Not null
                // Postcondition: Rating set to value
                set;
            }

            public override MediaType Medium
            {
                // Precondition:    none
                // Post condition:  medium returned
                get
                {
                    return _medium;
                }

                // Precondition:    is a dvd, bluray,  or vhs mediatype
                // Postcondition:   medium is set to value
                set
                {
                    if (value == MediaType.DVD || value == MediaType.BLURAY || value == MediaType.VHS)
                        _medium = value;
                    else
                        throw new ArgumentOutOfRangeException("Must be DVD, BLU RAY, or VHS!!!");
                }
            }

            // Precondition:    Days late >= 0
            // Postcondition:   Late fee per day calulated and returned
            public override decimal CalcLateFee(int daysLate)
            {
                if (daysLate < 0)
                    throw new ArgumentOutOfRangeException($"{nameof(daysLate)}",
                            $"{nameof(daysLate)} must be >= 0");
                else if (Medium == MediaType.BLURAY)
                    return daysLate * BLURAY_DAILY_LATE_FEE;
                else
                    return daysLate * DVD_VHS_DAILY_LATE_FEE;

            }

            // Precondition:  None
            // Postcondition: A string is returned presenting the libary movie's data on separate lines
            public override string ToString()
            {
                string NL = Environment.NewLine; // NewLine shortcut
                string checkedOutBy; // Holds checked out message

                if (IsCheckedOut())
                    checkedOutBy = $"Checked Out By: {NL}{Patron}";
                else
                    checkedOutBy = "Not Checked Out";

                return $"Library Movie{NL}" + base.ToString() + $"{NL}Director: {Director}" + $"{NL}Rating: {Rating}";
            }
        }
    }
}
