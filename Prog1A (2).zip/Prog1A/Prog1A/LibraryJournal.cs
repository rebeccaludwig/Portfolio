﻿// Grading ID: D1474
// Program number: 1A
// Due date: Feb 15, 2017 
// Course section: 200-01
// Description: this class returns info for journals checked out from library and calulates any late fees


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    class LibraryJournal : LibraryPeriodical
    {
        private string _discipline; // journal's discipline
        private string _editor;     // jounals' editor

        public const decimal DAILY_LATE_FEE = .75M; // daily late fee

        // Preconditions: not null values meet requirements
        // Postconditions: values are returned
        public LibraryJournal(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod, string theCallNumber, int theVolume, int theNumber, string theDiscipline, string theEditor)
        : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theVolume, theNumber)
        {
            Discipline = theDiscipline;
            Editor = theEditor;
        }

        public string Discipline
        {
            // Precondition:  None
            // Postcondition: The discipline returned
            get
            {
                return _discipline;
            }

            // Precondition:  Not null
            // Postcondition: The discipline is set to value
            set
            {
                // Since empty editor is OK, just change null to empty string
                _discipline = (value == null ? string.Empty : value.Trim());
            }
        }

        public string Editor
        {
            // Precondition:  None
            // Postcondition: The editor returned
            get
            {
                return _editor;
            }

            // Precondition:  Not null
            // Postcondition: The editor is set to value
            set
            {
                // Since empty editor is OK, just change null to empty string
                _editor = (value == null ? string.Empty : value.Trim());
            }
        }

        // Precondition:    Days late >= 0
        // Postcondition:   Late fee per day calulated and returned
        public override decimal CalcLateFee(int daysLate)
        {
            if (daysLate < 0)
                throw new ArgumentOutOfRangeException($"{nameof(daysLate)}",
                        $"{nameof(daysLate)} must be >= 0");
            else
                return daysLate * DAILY_LATE_FEE;

        }

        // Precondition:  None
        // Postcondition: A string is returned presenting the libary movie's data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";

            return $"Library Journal{NL}" + base.ToString() + $"{NL}Discipline: {Discipline}" + $"{NL}Editor: {Editor}";
        }
    }
}
