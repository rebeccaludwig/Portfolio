﻿// Grading ID: D1474
// Program number: 1A
// Due date: Feb 15, 2017 
// Course section: 200-01
// Description: this class displays info for music checked out from library and calculates any late fees

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public class LibraryMusic : LibraryMediaItem
    {
        public const decimal DAILY_LATE_FEE = .50M; // Daily late fee
        public const decimal MAX_FEE = 20.00M; // Max late fee

        private int _numTracks; // Number of tracks
        private string _artist;   // the music's artist
    
        private MediaType _medium; // Medium

        // Precondition: non null conditions
        // Postcondition: Movie initailized with values
        public LibraryMusic(string theTitle, string thePublisher, int theCopyrightYear,int theLoanPeriod, string theCallNumber, double theDuration, string theArtist, string theMedium, int theNumTracks)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theDuration)
        {
            Artist = theArtist;
            Medium = theMedium;
            NumTracks = theNumTracks;

        }
        public string Artist
        {
            // Precondition:  None
            // Postcondition: The artist returned
            get
            {
                return _artist;
            }

            // Precondition:  Not null
            // Postcondition: The artist is set to value
            set
            {
                // Since empty artist is OK, just change null to empty string
                _artist = (value == null ? string.Empty : value.Trim());
            }
        }
        public int NumTracks
        {
            // Precondition:  None
            // Postcondition: The num tracks returned
            get
            {
                return _numTracks;
            }
            // Precondition:  >= 0
            // Postcondition: The num tracks set to value
            set
            {
                if (value >= 0)
                    _numTracks = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(NumTracks)}", value,
                        $"{nameof(NumTracks)} must be >= 0");
            }
        }

        public override MediaType Medium
        {
            // Precondition:    none
            // Post condition:  medium returned
            get
            {
                return _medium;
            }

            // Precondition:    is a cd, sacd, or vinyl mediatype
            // Postcondition:   medium is set to value
            set
            {
                if (value == MediaType.CD || value == MediaType.SACD || value == MediaType.VINYL)
                    _medium = value;
                else
                    throw new ArgumentOutOfRangeException("Must be CD, SACD, or VINYL!!!");
            }
        }

        // Precondition:    Days late >= 0
        // Postcondition:   Late fee per day calulated and returned
        public override decimal CalcLateFee(int daysLate)
        {
            decimal totalFee = 0M; // holds fee

            if (daysLate < 0)
                throw new ArgumentOutOfRangeException($"{nameof(daysLate)}",
                        $"{nameof(daysLate)} must be >= 0");
            else
                totalFee = daysLate * DAILY_LATE_FEE;

            return Math.Min(totalFee, MAX_FEE);

        }

        // Precondition:  None
        // Postcondition: A string is returned presenting the libary movie's data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";

            return $"Library Movie{NL}" + base.ToString() + $"{NL}Artist: {Artist}" + $"{NL}Medium: {Medium}";
        }
    }
}
}
