﻿// Grading ID: D1474
// Program number: 1A
// Due date: Feb 15, 2017 
// Course section: 200-01
// Description: this class displays info for library books checked out from library and calculates any late fees

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public class LibraryBook : LibraryItem
    {
        public const decimal DAILY_LATE_FEE = .25M; // Cons late fee

        private string _author;     // The book's author

        // Precondition:  All values >= 0.
        // Postcondition: The library book initializes values for title, author, publisher, copyright year, loan period, and call number. Item not checked out.
        public LibraryBook(string theTitle, string theAuthor, string thePublisher, int theCopyrightYear, int theLoanPeriod, string theCallNumber) :
                    base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            Author = theAuthor;
        }

        public string Author
        {
            // Precondition:  None
            // Postcondition: The author returned
            get
            {
                return _author;
            }

            // Precondition:  Not null
            // Postcondition: The auther is set to value
            set
            {
                // Since empty author is OK, just change null to empty string
                _author = (value == null ? string.Empty : value.Trim());
            }
        }

        // Precondition:    Days late >= 0
        // Postcondition:   Late fee per day calulated and returned
        public override decimal CalcLateFee(int daysLate)
        {
            if (daysLate >= 0)
                return daysLate * DAILY_LATE_FEE;
            else
                throw new ArgumentOutOfRangeException($"{nameof(daysLate)}",
                        $"{nameof(daysLate)} must be >= 0");
        }

        // Precondition:  None
        // Postcondition: A string is returned presenting the libary book's data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";

            return $"Library Book{NL}" + base.ToString() + $"{NL}Author: {Author}";
        }
    }
}
