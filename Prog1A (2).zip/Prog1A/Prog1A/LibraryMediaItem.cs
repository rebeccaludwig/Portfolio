﻿// Grading ID: D1474
// Program number: 1A
// Due date: Feb 15, 2017 
// Course section: 200-01
// Description: this class gets info for media type library items and provides info for sub classes 


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public abstract class LibraryMediaItem : LibraryItem
    {
        public enum MediaType { DVD, BLURAY, VHS, CD, SACD, VINYL }; // media types

        private double _duration;  // The item's duration
        public string _mediaType; // The item's media type


        // String names for media types
        private string[] MediaTypes = { "DVD", "BLURAY", "VHS", "CD", "SACD", "VINYL" };

        // Precondition:    Non null values
        // Postcondition:   Media item initionalized with values
        public LibraryMediaItem(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod, string theCallNumber, double theDuration) : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            Duration = theDuration;
        }

        public abstract MediaType Medium
        {
            // Precondition:  None
            // Postcondition: Media returned
            get;

            // Precondition:  Not null
            // Postcondition: Media set to value
            set;
        }

        public double Duration
        {
            // Precondition:  None
            // Postcondition: The duration returned
            get
            {
                return _duration;
            }
            // Precondition:  >= 0
            // Postcondition: The duration set to value
            set
            {
                if (value >= 0)
                    _duration = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Duration)}", value,
                        $"{nameof(Duration)} must be >= 0");
            }
        }

        // Precondition:  None
        // Postcondition: A string is returned presenting the libary book's data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut
            string checkedOutBy; // Holds checked out message

            if (IsCheckedOut())
                checkedOutBy = $"Checked Out By: {NL}{Patron}";
            else
                checkedOutBy = "Not Checked Out";

            return $"Media Item{NL}" + $"Media Type: {Medium}{NL}" + base.ToString() + $"{NL}Duration: {Duration}";
        }

    }

}