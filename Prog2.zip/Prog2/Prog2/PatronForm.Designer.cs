﻿namespace LibraryItems
{
    partial class AddPatronForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.okBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.patronNameLbl = new System.Windows.Forms.Label();
            this.patronNameTxtBox = new System.Windows.Forms.TextBox();
            this.patronIdTxtBox = new System.Windows.Forms.TextBox();
            this.patronIdLbl = new System.Windows.Forms.Label();
            this.patronErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.patronErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(50, 112);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(75, 23);
            this.okBtn.TabIndex = 0;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(131, 112);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(75, 23);
            this.cancelBtn.TabIndex = 1;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            // 
            // patronNameLbl
            // 
            this.patronNameLbl.AutoSize = true;
            this.patronNameLbl.Location = new System.Drawing.Point(27, 22);
            this.patronNameLbl.Name = "patronNameLbl";
            this.patronNameLbl.Size = new System.Drawing.Size(38, 13);
            this.patronNameLbl.TabIndex = 2;
            this.patronNameLbl.Text = "Name:";
            // 
            // patronNameTxtBox
            // 
            this.patronNameTxtBox.Location = new System.Drawing.Point(71, 19);
            this.patronNameTxtBox.Name = "patronNameTxtBox";
            this.patronNameTxtBox.Size = new System.Drawing.Size(135, 20);
            this.patronNameTxtBox.TabIndex = 3;
            // 
            // patronIdTxtBox
            // 
            this.patronIdTxtBox.Location = new System.Drawing.Point(71, 64);
            this.patronIdTxtBox.Name = "patronIdTxtBox";
            this.patronIdTxtBox.Size = new System.Drawing.Size(135, 20);
            this.patronIdTxtBox.TabIndex = 4;
            // 
            // patronIdLbl
            // 
            this.patronIdLbl.AutoSize = true;
            this.patronIdLbl.Location = new System.Drawing.Point(27, 67);
            this.patronIdLbl.Name = "patronIdLbl";
            this.patronIdLbl.Size = new System.Drawing.Size(21, 13);
            this.patronIdLbl.TabIndex = 5;
            this.patronIdLbl.Text = "ID:";
            // 
            // AddPatronForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(249, 151);
            this.Controls.Add(this.patronIdLbl);
            this.Controls.Add(this.patronIdTxtBox);
            this.Controls.Add(this.patronNameTxtBox);
            this.Controls.Add(this.patronNameLbl);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.okBtn);
            this.Name = "AddPatronForm";
            this.Text = "Insert Patron";
            ((System.ComponentModel.ISupportInitialize)(this.patronErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Label patronNameLbl;
        private System.Windows.Forms.TextBox patronNameTxtBox;
        private System.Windows.Forms.TextBox patronIdTxtBox;
        private System.Windows.Forms.Label patronIdLbl;
        private System.Windows.Forms.ErrorProvider patronErrorProvider;
    }
}