﻿// D1474
// Program 2
// CIS 200-01
// March 9, 2017
// PatronForm.cs
// Patron item - Display a dialog box that will be used to enter patron information. When successfully submitted, add a patron to the library with the provided information. Use form validation and/or exception handling to ensure that only valid data is used. The end user should never see an exception, regardless of what they type or what they click on the dialog box.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    internal partial class AddPatronForm : Form
    {
        // Precondition:    None.
        // Postcondition:   Display form.
        public AddPatronForm()
        {
            InitializeComponent();
        }

        public string PatronName
        {
            //Precondition:     None.
            //Postcondition:    Get and return text from patron name text box.
            get
            {
                return patronNameTxtBox.Text;
            }

            //Precontion:       None.
            //Postcondition:    Set patron name to value from text box.
            set
            {
                patronNameTxtBox.Text = value;
            }
        }
        
        public string PatronId
        {
            //Precondition:     None.
            //Postcondition:    Get and return text from patron id text box.
            get
            {
                return patronIdTxtBox.Text;
            }

            //Precontion:       None.
            //Postcondition:    Set patron id to value from text box.
            set
            {
                patronIdTxtBox.Text = value;
            }
        }

        // Precondition:    Text box manipulated.
        // Postcondition:   If field is empty error message displayed in text box, can not leave text box until valid input is entered.
        private void patronNameTxtBox_Validate(object sender, CancelEventArgs e)
        {
            if (patronNameTxtBox.TextLength == 0)
            {
                e.Cancel = true;
                this.patronErrorProvider.SetError(patronNameTxtBox, "Patron Name empty");
            }
        }

        // Precondition:  Validation successful.
        // Postcondition: Can move away from current text box.
        private void patronNameTxt_Validated(object sender, EventArgs e)
        {
            this.patronErrorProvider.SetError(patronNameTxtBox, "");
        }

        // Precondition:    Text box manipulated.
        // Postcondition:   If field is empty error message displayed in text box, can not leave text box until valid input is entered.
        private void patronIdTxtBox_Validate(object sender, CancelEventArgs e)
        {
            if (patronIdTxtBox.TextLength == 0)
            {
                e.Cancel = true;
                this.patronErrorProvider.SetError(patronIdTxtBox, "Patron ID empty");
            }
        }

        // Precondition:  Validation successful.
        // Postcondition: Can move away from current text box.
        private void patronIdTxt_Validated(object sender, EventArgs e)
        {
            this.patronErrorProvider.SetError(patronIdTxtBox, "");
        }

        // Precondition:    Ok button clicked
        // Postcondition:   Accept input close form.
        private void okBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        // Precondition:  Cancel button clicked
        // Postcondition: Close form cancel actions, p. 581 mouse down to remove focus to cancel validaions
        private void cancelBtn_Click(object sender, MouseEventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
