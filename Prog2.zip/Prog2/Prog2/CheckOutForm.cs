﻿// D1474
// Program 2
// CIS 200-01
// March 9, 2017
// CheckOutForm.cs
// CheckOut item - Display a dialog box that will be used to check out an item from the library. The user must select which item is to be checked out by which patron. For this form, you will practice using combo boxes. One combo box will contain the items and another will contain the patrons. Specifically, populate the items combo box using the item's title and call number (as in "The Wright Guide to C#, ZZ225 3G"). For the moment, it is OK to list all the items in the library including those that may already be checked out (maybe the patron wishes to renew the item?). Populate the patrons combo box using each patron's name and ID (as in "Ima Reader, 12345"). When successfully submitted, check out the specified item from the library by the specified patron. Use form validation and/or exception handling to ensure that only valid data is used. The end user should never see an exception, regardless of what they type or what they click on the dialog box.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    internal partial class CheckOutForm : Form
    {
        private List<LibraryItem> items;        // List of items
        private List<LibraryPatron> patrons;    // List of patrons

        // Precondition:    Populate item and patron combo boxes with list items.
        // Postcondition:   Display form.
        public CheckOutForm(List<LibraryItem> itemList, List<LibraryPatron> patronList)
        {
            InitializeComponent();

            items = itemList;
            patrons = patronList;
        }

        // Precondition:    None.
        // Postcondition:   Formats and lits items in combo boxes
        private void CheckoutForm_List(object sender, EventArgs e)
        {
            foreach (LibraryItem item in items)
            {
                itemCmbBox.Items.Add(item.Title + ", " + item.CallNumber);
            }

            foreach (LibraryPatron patron in patrons)
            {
                patronCmbBox.Items.Add(patron.PatronName + ", " + patron.PatronID);
            }
        }

        // Precondition:  None
        // Postcondition: Returns index of items
        public int ItemList
        {    
            get
            {
                return itemCmbBox.SelectedIndex;
            }
        }

        // Precondition:  None
        // Postcondition: Returns index of patrons
        public int PatronList
        {
            get
            {
                return patronCmbBox.SelectedIndex;
            }
        }

        // Precondition:    Combo box manipulated
        // Postcondition:   If item not selected error message displayed, can not leave move forward until item is selected.
        private void itemCbo_Validate(object sender, CancelEventArgs e)
        {
            if (itemCmbBox.SelectedIndex == -1)
            {
                e.Cancel = true;
                this.checkOutErrorProvider.SetError(itemCmbBox, "Must select Item");
            }
        }

        // Precondition:    Validation successful.
        // Postcondition:   Can move away from current combo box.
        private void itemCbo_Validated(object sender, EventArgs e)
        {
            this.checkOutErrorProvider.SetError(itemCmbBox, "");
        }

        // Precondition:    Combo box manipulated
        // Postcondition:   If patron not selected error message displayed, can not leave move forward until patron is selected.
        private void patronCbo_Validate(object sender, CancelEventArgs e)
        {
            if (patronCmbBox.SelectedIndex == -1)
            {
                e.Cancel = true;
                this.checkOutErrorProvider.SetError(patronCmbBox, "Must select Item");
            }
        }

        // Precondition:    Validation successful.
        // Postcondition:   Can move away from current combo box.
        private void patronCbo_Validated(object sender, EventArgs e)
        {
            this.checkOutErrorProvider.SetError(patronCmbBox, "");
        }

        // Precondition:    Ok button clicked
        // Postcondition:   Accept input close form.
        private void okBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        // Precondition:    Cancel button clicked
        // Postcondition:   Close form cancel actions, *****p. 581 mouse down to remove focus to cancel validaions
        private void cancelBtn_Click(object sender, MouseEventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
