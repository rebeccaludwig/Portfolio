﻿namespace LibraryItems
{
    partial class BookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.titleTxtBox = new System.Windows.Forms.TextBox();
            this.publisherTxtBox = new System.Windows.Forms.TextBox();
            this.copyrightYearTxtBox = new System.Windows.Forms.TextBox();
            this.loanPeriodTxtBox = new System.Windows.Forms.TextBox();
            this.callNumberTxtBox = new System.Windows.Forms.TextBox();
            this.authorTxtBox = new System.Windows.Forms.TextBox();
            this.titleLbl = new System.Windows.Forms.Label();
            this.publisherLbl = new System.Windows.Forms.Label();
            this.copyrightYearLbl = new System.Windows.Forms.Label();
            this.loanPeriodLbl = new System.Windows.Forms.Label();
            this.callNumberLbl = new System.Windows.Forms.Label();
            this.authorLbl = new System.Windows.Forms.Label();
            this.okBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.bookErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bookErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // titleTxtBox
            // 
            this.titleTxtBox.Location = new System.Drawing.Point(123, 12);
            this.titleTxtBox.Name = "titleTxtBox";
            this.titleTxtBox.Size = new System.Drawing.Size(157, 20);
            this.titleTxtBox.TabIndex = 0;
            // 
            // publisherTxtBox
            // 
            this.publisherTxtBox.Location = new System.Drawing.Point(123, 38);
            this.publisherTxtBox.Name = "publisherTxtBox";
            this.publisherTxtBox.Size = new System.Drawing.Size(157, 20);
            this.publisherTxtBox.TabIndex = 1;
            // 
            // copyrightYearTxtBox
            // 
            this.copyrightYearTxtBox.Location = new System.Drawing.Point(123, 64);
            this.copyrightYearTxtBox.Name = "copyrightYearTxtBox";
            this.copyrightYearTxtBox.Size = new System.Drawing.Size(157, 20);
            this.copyrightYearTxtBox.TabIndex = 2;
            // 
            // loanPeriodTxtBox
            // 
            this.loanPeriodTxtBox.Location = new System.Drawing.Point(123, 90);
            this.loanPeriodTxtBox.Name = "loanPeriodTxtBox";
            this.loanPeriodTxtBox.Size = new System.Drawing.Size(157, 20);
            this.loanPeriodTxtBox.TabIndex = 3;
            // 
            // callNumberTxtBox
            // 
            this.callNumberTxtBox.Location = new System.Drawing.Point(123, 116);
            this.callNumberTxtBox.Name = "callNumberTxtBox";
            this.callNumberTxtBox.Size = new System.Drawing.Size(157, 20);
            this.callNumberTxtBox.TabIndex = 4;
            // 
            // authorTxtBox
            // 
            this.authorTxtBox.Location = new System.Drawing.Point(123, 142);
            this.authorTxtBox.Name = "authorTxtBox";
            this.authorTxtBox.Size = new System.Drawing.Size(157, 20);
            this.authorTxtBox.TabIndex = 5;
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.Location = new System.Drawing.Point(12, 15);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(30, 13);
            this.titleLbl.TabIndex = 6;
            this.titleLbl.Text = "Title:";
            // 
            // publisherLbl
            // 
            this.publisherLbl.AutoSize = true;
            this.publisherLbl.Location = new System.Drawing.Point(12, 41);
            this.publisherLbl.Name = "publisherLbl";
            this.publisherLbl.Size = new System.Drawing.Size(53, 13);
            this.publisherLbl.TabIndex = 7;
            this.publisherLbl.Text = "Publisher:";
            // 
            // copyrightYearLbl
            // 
            this.copyrightYearLbl.AutoSize = true;
            this.copyrightYearLbl.Location = new System.Drawing.Point(12, 67);
            this.copyrightYearLbl.Name = "copyrightYearLbl";
            this.copyrightYearLbl.Size = new System.Drawing.Size(79, 13);
            this.copyrightYearLbl.TabIndex = 8;
            this.copyrightYearLbl.Text = "Copyright Year:";
            // 
            // loanPeriodLbl
            // 
            this.loanPeriodLbl.AutoSize = true;
            this.loanPeriodLbl.Location = new System.Drawing.Point(12, 93);
            this.loanPeriodLbl.Name = "loanPeriodLbl";
            this.loanPeriodLbl.Size = new System.Drawing.Size(67, 13);
            this.loanPeriodLbl.TabIndex = 9;
            this.loanPeriodLbl.Text = "Loan Period:";
            // 
            // callNumberLbl
            // 
            this.callNumberLbl.AutoSize = true;
            this.callNumberLbl.Location = new System.Drawing.Point(12, 119);
            this.callNumberLbl.Name = "callNumberLbl";
            this.callNumberLbl.Size = new System.Drawing.Size(67, 13);
            this.callNumberLbl.TabIndex = 10;
            this.callNumberLbl.Text = "Call Number:";
            // 
            // authorLbl
            // 
            this.authorLbl.AutoSize = true;
            this.authorLbl.Location = new System.Drawing.Point(12, 145);
            this.authorLbl.Name = "authorLbl";
            this.authorLbl.Size = new System.Drawing.Size(41, 13);
            this.authorLbl.TabIndex = 11;
            this.authorLbl.Text = "Author:";
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(57, 187);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(88, 23);
            this.okBtn.TabIndex = 12;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(151, 187);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(88, 23);
            this.cancelBtn.TabIndex = 13;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            // 
            // bookErrorProvider
            // 
            this.bookErrorProvider.ContainerControl = this;
            // 
            // BookForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 222);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.authorLbl);
            this.Controls.Add(this.callNumberLbl);
            this.Controls.Add(this.loanPeriodLbl);
            this.Controls.Add(this.copyrightYearLbl);
            this.Controls.Add(this.publisherLbl);
            this.Controls.Add(this.titleLbl);
            this.Controls.Add(this.authorTxtBox);
            this.Controls.Add(this.callNumberTxtBox);
            this.Controls.Add(this.loanPeriodTxtBox);
            this.Controls.Add(this.copyrightYearTxtBox);
            this.Controls.Add(this.publisherTxtBox);
            this.Controls.Add(this.titleTxtBox);
            this.Name = "BookForm";
            this.Text = "Insert Book";
            ((System.ComponentModel.ISupportInitialize)(this.bookErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox titleTxtBox;
        private System.Windows.Forms.TextBox publisherTxtBox;
        private System.Windows.Forms.TextBox copyrightYearTxtBox;
        private System.Windows.Forms.TextBox loanPeriodTxtBox;
        private System.Windows.Forms.TextBox callNumberTxtBox;
        private System.Windows.Forms.TextBox authorTxtBox;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Label publisherLbl;
        private System.Windows.Forms.Label copyrightYearLbl;
        private System.Windows.Forms.Label loanPeriodLbl;
        private System.Windows.Forms.Label callNumberLbl;
        private System.Windows.Forms.Label authorLbl;
        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.ErrorProvider bookErrorProvider;
    }
}