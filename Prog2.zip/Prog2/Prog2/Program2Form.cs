﻿// D1474
// Program 2
// CIS 200-01
// March 9, 2017
// Program2Form.cs
// GUI that will perform tasks for library. Insert library books and patrons, check out and return items, display reports.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
     partial class Program2Form : Form
    {
        private Library theLibrary;
        private List<LibraryItem> items;
        private List<LibraryPatron> patrons;

        // Precondition:    None.
        // Postcondition:   Display form.
        public Program2Form()
        {
            InitializeComponent();

            theLibrary = new Library();
            items = theLibrary.GetItemsList();
            patrons = theLibrary.GetPatronsList();
            
            // Add test patrons
            patrons.Add(new LibraryPatron("Ima Reader", "12345"));
            patrons.Add(new LibraryPatron("Jane Doe", "11223"));
            patrons.Add(new LibraryPatron("John Smith", "54321"));
            patrons.Add(new LibraryPatron("James T. Kirk", "98765"));
            patrons.Add(new LibraryPatron("Jean-Luc Picard", "33456"));

            // Add test books
            items.Add(new LibraryBook("The Wright Guide to C#", "UofL Press", 2010, 14, "ZZ25 3G", "Andrew Wright"));
            items.Add(new LibraryBook("Harriet Pooter", "Stealer Books", 2000, 21, "AB73 ZF", "IP Thief"));
            items.Add(new LibraryBook("C# for Beginners", "Book Pub", 2017, 7, "EY23 9T", "Rob Smith"));
            items.Add(new LibraryBook("Cooking 101", "PengPub", 1999, 28, "TTR4 23", "Tammy Tick"));
            items.Add(new LibraryBook("World War 3", "Trump Books", 2019, 7, "RE90 4G", "Donald Trump"));

        }

        // About item - Display a dialog box with basic information including your Grading ID, program number, due date, etc. You may create a custom form to display or use MessageBox.Show to create.
        // Precondtions:    None
        // Postconditions:  Displays message box with info
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Program 2: \nThis a simple GUI that allows users to create patrons and books that will be added to the library. Books may be checked out and returned. Various reports may be generated. \n\nGrading ID: D1474 \nDue Date: March 9, 2017", "About", MessageBoxButtons.OK);
        }

        // Exit item - Will close application
        // Precondtions:    None
        // Postconditions:  Exits applicaiton
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Patron item - Display a dialog box that will be used to enter patron information. When successfully submitted, add a patron to the library with the provided information. Use form validation and/or exception handling to ensure that only valid data is used. The end user should never see an exception, regardless of what they type or what they click on the dialog box.
        // Precondtions:    Ok button clicked, validated by form ***page 711
        // Postconditions:  Adds patron to library if info entered and submitted
        private void patronToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddPatronForm addPatronForm = new AddPatronForm();

            DialogResult patronReport = addPatronForm.ShowDialog();

            if (patronReport == DialogResult.OK)
            {
                LibraryPatron addPatron = new LibraryPatron (addPatronForm.PatronName, addPatronForm.PatronId);

                patrons.Add(addPatron);
            }
        }

        // Book item - Display a dialog box that will be used to enter library book information. When successfully submitted, add a book to the library with the provided information. Use form validation and/or exception handling to ensure that only valid data is used. The end user should never see an exception, regardless of what they type or what they click on the dialog box.
        // Precondtions:    Ok button clicked, validated by form
        // Postconditions:  Book added to library
        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookForm addBookForm = new BookForm();

            DialogResult bookReport = addBookForm.ShowDialog();

            if (bookReport == DialogResult.OK)
            {
                LibraryBook addBook = new LibraryBook(addBookForm.BookTitle, addBookForm.BookPublisher, int.Parse(addBookForm.BookCopyrightYear), int.Parse(addBookForm.BookLoanPeriod), addBookForm.BookCallNumber, addBookForm.BookAuthor);

                items.Add(addBook);
            }
        }

        // Precondtions:    Ok button clicked
        // Postconditions:  Checks out selected item by selected patron
        private void checkOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<LibraryPatron> patron = theLibrary.GetPatronsList();//copt the lists over
            List<LibraryItem> item = theLibrary.GetItemsList();

            CheckOutForm checkOut = new CheckOutForm(item, patron);

            DialogResult checkOutReport = checkOut.ShowDialog();
        }

        // Precondtions:    Ok button clicked
        // Postconditions:  Returns selected item
        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<LibraryItem> item = theLibrary.GetItemsList();

            ReturnForm checkOut = new ReturnForm(item);

            DialogResult checkOutReport = checkOut.ShowDialog();
        }

        // Precondtions:
        // Postconditions: 
        private void extraCreditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // List of books -> list of checked out books -> list that stores value in list 
            //    list of checked out 
        }

        // Precondtions:    Report clicked
        // Postconditions:  Displays list and count
        private void patronListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder patronReport = new StringBuilder();

            patronReport.Append(String.Format("Patron List"));
            patronReport.Append(Environment.NewLine);
            patronReport.Append(String.Format("Count: {0} patrons", patrons.Count()));
            patronReport.Append(Environment.NewLine);
            patronReport.Append(Environment.NewLine);

            foreach (LibraryPatron patron in patrons)    
            {
                patronReport.Append(patron.ToString());
                patronReport.Append(Environment.NewLine);
                patronReport.Append(Environment.NewLine);
            }

            reportTxtBox.Text = patronReport.ToString();
        }

        // Precondtions:    Report clicked
        // Postconditions:  Displays list and count 
        private void itemListToolStripMenuItem_Click(object sender, EventArgs e)
        {

            StringBuilder itemReport = new StringBuilder();

            itemReport.Append(String.Format("Item List"));
            itemReport.Append(Environment.NewLine);
            itemReport.Append(String.Format("Count: {0} items", items.Count()));
            itemReport.Append(Environment.NewLine);
            itemReport.Append(Environment.NewLine);

            foreach (LibraryItem item in items)
            {
                itemReport.Append(item.ToString());
                itemReport.Append(Environment.NewLine);
                itemReport.Append(Environment.NewLine);
            }

            reportTxtBox.Text = itemReport.ToString();
        }

        // Precondtions:    Report clicked
        // Postconditions:  Displays list and count 
        private void checkedOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder checkedOutItemReport = new StringBuilder();

            checkedOutItemReport.Append(String.Format("Checked Out Item List"));
            checkedOutItemReport.Append(Environment.NewLine);
            checkedOutItemReport.Append(String.Format("Count: {0} items", items.Count()));
            checkedOutItemReport.Append(Environment.NewLine);
            checkedOutItemReport.Append(Environment.NewLine);

            foreach (LibraryItem item in items)
            {
                checkedOutItemReport.Append(item.ToString());
                checkedOutItemReport.Append(Environment.NewLine);
                checkedOutItemReport.Append(Environment.NewLine);
            }

            reportTxtBox.Text = checkedOutItemReport.ToString();
        }
    }
}
