﻿namespace LibraryItems
{
    partial class CheckOutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.checkOutErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.itemCmbBox = new System.Windows.Forms.ComboBox();
            this.patronCmbBox = new System.Windows.Forms.ComboBox();
            this.selectItemLbl = new System.Windows.Forms.Label();
            this.selectPatronLbl = new System.Windows.Forms.Label();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.okBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.checkOutErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // checkOutErrorProvider
            // 
            this.checkOutErrorProvider.ContainerControl = this;
            // 
            // itemCmbBox
            // 
            this.itemCmbBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.itemCmbBox.FormattingEnabled = true;
            this.itemCmbBox.Location = new System.Drawing.Point(92, 25);
            this.itemCmbBox.Name = "itemCmbBox";
            this.itemCmbBox.Size = new System.Drawing.Size(188, 21);
            this.itemCmbBox.TabIndex = 0;
            // 
            // patronCmbBox
            // 
            this.patronCmbBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.patronCmbBox.FormattingEnabled = true;
            this.patronCmbBox.Location = new System.Drawing.Point(92, 69);
            this.patronCmbBox.Name = "patronCmbBox";
            this.patronCmbBox.Size = new System.Drawing.Size(188, 21);
            this.patronCmbBox.TabIndex = 1;
            // 
            // selectItemLbl
            // 
            this.selectItemLbl.AutoSize = true;
            this.selectItemLbl.Location = new System.Drawing.Point(12, 28);
            this.selectItemLbl.Name = "selectItemLbl";
            this.selectItemLbl.Size = new System.Drawing.Size(63, 13);
            this.selectItemLbl.TabIndex = 2;
            this.selectItemLbl.Text = "Select Item:";
            // 
            // selectPatronLbl
            // 
            this.selectPatronLbl.AutoSize = true;
            this.selectPatronLbl.Location = new System.Drawing.Point(12, 72);
            this.selectPatronLbl.Name = "selectPatronLbl";
            this.selectPatronLbl.Size = new System.Drawing.Size(74, 13);
            this.selectPatronLbl.TabIndex = 3;
            this.selectPatronLbl.Text = "Select Patron:";
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(149, 117);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(88, 23);
            this.cancelBtn.TabIndex = 15;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(55, 117);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(88, 23);
            this.okBtn.TabIndex = 14;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // CheckOutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 161);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.selectPatronLbl);
            this.Controls.Add(this.selectItemLbl);
            this.Controls.Add(this.patronCmbBox);
            this.Controls.Add(this.itemCmbBox);
            this.Name = "CheckOutForm";
            this.Text = "Check Out Item";
            ((System.ComponentModel.ISupportInitialize)(this.checkOutErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ErrorProvider checkOutErrorProvider;
        private System.Windows.Forms.Label selectPatronLbl;
        private System.Windows.Forms.Label selectItemLbl;
        private System.Windows.Forms.ComboBox patronCmbBox;
        private System.Windows.Forms.ComboBox itemCmbBox;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Button okBtn;
    }
}