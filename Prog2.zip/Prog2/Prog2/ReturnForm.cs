﻿// D1474
// Program 2
// CIS 200-01
// March 9, 2017
// ReturnForm.cs
// Return item - Display a dialog box that will be used to return an item to the library. The user must select which item is to be returned, again using a combo box. As with checking out, populate the items combo box using the item's title and call number (as in "The Wright Guide to C#, ZZ225 3G"). For the moment, it is OK to list all the items in the library including those that are not checked out. When successfully submitted, return the specified item to the shelf. Use form validation and/or exception handling to ensure that only valid data is used. The end user should never see an exception, regardless of what they type or what they click on the dialog box.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    internal partial class ReturnForm : Form
    {
        public ReturnForm()
        {
            InitializeComponent();
        }

        private List<LibraryItem> items;    // List of items

        // Precondition:    Populate item and patron combo boxes with list items.
        // Postcondition:   Display form.
        public ReturnForm(List<LibraryItem> itemList)
        {
            InitializeComponent();

            items = itemList;
        }

        // Precondition:    None.
        // Postcondition:   Formats and lits items in combo boxes
        private void CheckoutForm_List(object sender, EventArgs e)
        {
            foreach (LibraryItem item in items)
            {
                itemCmbBox.Items.Add(item.Title + ", " + item.CallNumber);
            }
        }

        // Precondition:    None
        // Postcondition:   Returns index of items
        public int ItemList
        {
            get
            {
                return itemCmbBox.SelectedIndex;
            }
        }

        // Precondition:    Combo box manipulated
        // Postcondition:   If item not selected error message displayed, can not leave move forward until item is selected.
        private void itemCbo_Validate(object sender, CancelEventArgs e)
        {
            if (itemCmbBox.SelectedIndex == -1)
            {
                e.Cancel = true;
                this.returnErrorProvider.SetError(itemCmbBox, "Must select Item");
            }
        }

        // Precondition:    Validation successful.
        // Postcondition:   Can move away from current combo box.
        private void itemCbo_Validated(object sender, EventArgs e)
        {
            this.returnErrorProvider.SetError(itemCmbBox, "");
        }

        // Precondition:    Ok button clicked
        // Postcondition:   Accept input close form.
        private void okBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        // Precondition:    Cancel button clicked
        // Postcondition:   Close form cancel actions, p. 581 mouse down to remove focus to cancel validaions
        private void cancelBtn_Click(object sender, MouseEventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
