﻿// D1474
// Program 2
// CIS 200-01
// March 9, 2017
// BookForm.cs
// Book item - Display a dialog box that will be used to enter library book information. When successfully submitted, add a book to the library with the provided information. Use form validation and/or exception handling to ensure that only valid data is used. The end user should never see an exception, regardless of what they type or what they click on the dialog box.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class BookForm : Form
    {
        // Precondition:    None.
        // Postcondition:   Display form.
        public BookForm()
        {
            InitializeComponent();
        }

        public string BookTitle
        {
            //Precondition:     None.
            //Postcondition:    Get and return text from text box.
            get
            {
                return titleTxtBox.Text;
            }

            //Precontion:       None.
            //Postcondition:    Set value from text box.
            set
            {
                titleTxtBox.Text = value;
            }
        }

        public string BookPublisher
        {
            //Precondition:     None.
            //Postcondition:    Get and return text from text box.
            get
            {
                return publisherTxtBox.Text;
            }

            //Precontion:       None.
            //Postcondition:    Set value from text box.
            set
            {
                publisherTxtBox.Text = value;
            }
        }

        public string BookCopyrightYear
        {
            //Precondition:     None.
            //Postcondition:    Get and return text from text box.
            get
            {
                return copyrightYearTxtBox.Text;
            }

            //Precontion:       None.
            //Postcondition:    Set value from text box.
            set
            {
                copyrightYearTxtBox.Text = value;
            }
        }

        public string BookLoanPeriod
        {
            //Precondition:     None.
            //Postcondition:    Get and return text from text box.
            get
            {
                return loanPeriodTxtBox.Text;
            }

            //Precontion:       None.
            //Postcondition:    Set value from text box.
            set
            {
                loanPeriodTxtBox.Text = value;
            }
        }

        public string BookCallNumber
        {
            //Precondition:     None.
            //Postcondition:    Get and return text from text box.
            get
            {
                return callNumberTxtBox.Text;
            }

            //Precontion:       None.
            //Postcondition:    Set value from text box.
            set
            {
                callNumberTxtBox.Text = value;
            }
        }

        public string BookAuthor
        {
            //Precondition:     None.
            //Postcondition:    Get and return text from author text box.
            get
            {
                return authorTxtBox.Text;
            }

            //Precontion:       None.
            //Postcondition:    Set autor to value from text box.
            set
            {
                authorTxtBox.Text = value;
            }
        }

        // Precondition:    Text box manipulated.
        // Postcondition:   If field is empty error message displayed in text box, can not leave text box until valid input is entered.
        private void titleTxtBox_Validate(object sender, CancelEventArgs e)
        {
            if (titleTxtBox.TextLength == 0)
            {
                e.Cancel = true;
                this.bookErrorProvider.SetError(titleTxtBox, "Item title empty");
            }
        }

        // Precondition:    Validation successful.
        // Postcondition:   Can move away from current text box.
        private void titleTxt_Validated(object sender, EventArgs e)
        {
            this.bookErrorProvider.SetError(titleTxtBox, "");
        }

        // Precondition:    Text box manipulated.
        // Postcondition:   If field is empty error message displayed in text box, can not leave text box until valid input is entered.
        private void publisherTxtBox_Validate(object sender, CancelEventArgs e)
        {
            if (publisherTxtBox.TextLength == 0)
            {
                e.Cancel = true;
                this.bookErrorProvider.SetError(publisherTxtBox, "Item publisher empty");
            }
        }

        // Precondition:    Validation successful.
        // Postcondition:   Can move away from current text box.
        private void publisherTxt_Validated(object sender, EventArgs e)
        {
            this.bookErrorProvider.SetError(publisherTxtBox, "");
        }

        // Precondition:    Text box manipulated.
        // Postcondition:   If field is empty error message displayed in text box, can not leave text box until valid input is entered.
        private void copyrightYearTxtBox_Validate(object sender, CancelEventArgs e)
        {
            if (copyrightYearTxtBox.TextLength == 0)
            {
                e.Cancel = true;
                this.bookErrorProvider.SetError(copyrightYearTxtBox, "Item copyright year empty");
            }
        }

        // Precondition:    Validation successful.
        // Postcondition:   Can move away from current text box.
        private void copyrightYearTxt_Validated(object sender, EventArgs e)
        {
            this.bookErrorProvider.SetError(copyrightYearTxtBox, "");
        }

        // Precondition:    Text box manipulated.
        // Postcondition:   If field is empty error message displayed in text box, can not leave text box until valid input is entered.
        private void loanPeriodTxtBox_Validate(object sender, CancelEventArgs e)
        {
            if (loanPeriodTxtBox.TextLength == 0)
            {
                e.Cancel = true;
                this.bookErrorProvider.SetError(loanPeriodTxtBox, "Item loan period empty");
            }
        }

        // Precondition:    Validation successful.
        // Postcondition:   Can move away from current text box.
        private void loanPeriodTxt_Validated(object sender, EventArgs e)
        {
            this.bookErrorProvider.SetError(loanPeriodTxtBox, "");
        }

        // Precondition:    Text box manipulated.
        // Postcondition:   If field is empty error message displayed in text box, can not leave text box until valid input is entered.
        private void callNumberTxtBox_Validate(object sender, CancelEventArgs e)
        {
            if (callNumberTxtBox.TextLength == 0)
            {
                e.Cancel = true;
                this.bookErrorProvider.SetError(callNumberTxtBox, "Item title empty");
            }
        }

        // Precondition:    Validation successful.
        // Postcondition:   Can move away from current text box.
        private void callNumberTxt_Validated(object sender, EventArgs e)
        {
            this.bookErrorProvider.SetError(callNumberTxtBox, "");
        }

        // Precondition:    Text box manipulated.
        // Postcondition:   If field is empty error message displayed in text box, can not leave text box until valid input is entered.
        private void authorTxtBox_Validate(object sender, CancelEventArgs e)
        {
            if (authorTxtBox.TextLength == 0)
            {
                e.Cancel = true;
                this.bookErrorProvider.SetError(authorTxtBox, "Book author empty");
            }
        }

        // Precondition:  Validation successful.
        // Postcondition: Can move away from current text box.
        private void authorTxt_Validated(object sender, EventArgs e)
        {
            this.bookErrorProvider.SetError(authorTxtBox, "");
        }

        // Precondition:    Ok button clicked
        // Postcondition:   Accept input close form.
        private void okBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        // Precondition:  Cancel button clicked
        // Postcondition: Close form cancel actions, p. 581 mouse down to remove focus to cancel validaions
        private void cancelBtn_Click(object sender, MouseEventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
