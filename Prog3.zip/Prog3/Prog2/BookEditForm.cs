﻿// Program 3
// CIS 200-01
// Due: 4/3/2017
// By: D1474

// File: BookEditForm.cs
// This class selects book from list to be edited

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class BookEditForm : Form
    {
        private List<LibraryBook> items;                // List of patrons
        private int selectBook;                         // moves to correct index

        // Precondition:    Click Edit > Book
        // Postcondition:   Edit Patron form loaded
        public BookEditForm()
        {
            InitializeComponent();
            items = new List<LibraryBook>();
        }

        // Precondition:    None
        // Postcondition:   Set values from list
        public BookEditForm(List<LibraryBook> bookList)
        {
            InitializeComponent();//init the form
            items = bookList;//set the list
            BookIndex = selectBook;//set the index value
        }

        // Precondition:    None
        // Postcondition:   Return selected patron by index
        public int BookIndex
        {
            get
            {
                return bookCbo.SelectedIndex;
            }

            set
            {
                selectBook = value;
            }
        }

        // Precondition:    form loaded
        // Postcondion:     books loaded into combobox
        private void BookEditForm_Load(object sender, EventArgs e)
        {
            foreach (LibraryBook item in items)
                bookCbo.Items.Add(item.Title);
        }

        // Precondition:    Click OK
        // Postcondition:   Patron index set
        private void okBtn_Click(object sender, EventArgs e)
        {
            int selectBook = bookCbo.SelectedIndex;
        }

        // Precondition:    Click Cancel
        // Postcondtion:    Edit dialog box closed and canceled
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
