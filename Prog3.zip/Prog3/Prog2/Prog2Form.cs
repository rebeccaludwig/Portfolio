﻿// Program 3
// CIS 200-01
// Due: 4/3/2017
// By: D1474

// File: Prog2Form.cs
// This class creates the main GUI for Program 2. It provides a
// File menu with About and Exit items, an Insert menu with Patron and
// Book items, an Item menu with Check Out and Return items, and a
// Report menu with Patron List, Item List, and Checked Out Items items.

// Extra Credit - Check Out and Return only show relevant items

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using LibraryItems;
using System.IO;

namespace LibraryItems
{
    [Serializable]
    public partial class Prog2Form : Form
    {
        private Library _lib;                                           // The library
        private List<LibraryPatron> patrons;                            // List of library patrons
        private List<LibraryItem> items;                                // List of library items
        private FileStream input;                                       // Stream for loading from a file
        private FileStream output;                                      // Stream for writing to a file
        private BinaryFormatter formatter = new BinaryFormatter();      // Object for recording in binary format
        private BinaryFormatter reader = new BinaryFormatter();         // Object for reading binary format

        // Precondition:  None
        // Postcondition: The form's GUI is prepared for display. A few test items and patrons
        //                are added to the library
        public Prog2Form()
        {
            InitializeComponent();

            _lib = new Library(); // Create the library

            items = _lib.GetItemsList();
            patrons = _lib.GetPatronsList();
        }

        // Precondition:  File, About menu item activated
        // Postcondition: Information about author displayed in dialog box
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NL = Environment.NewLine; // NewLine shortcut

            MessageBox.Show($"Program 3{NL}By: D1474{NL}CIS 200-01{NL}Spring 2017",
                "About Program 3");
        }

        // Precondition:  File, Exit menu item activated
        // Postcondition: The application is exited
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Precondition:  Report, Patron List menu item activated
        // Postcondition: The list of patrons is displayed in the reportTxt
        //                text box
        private void patronListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report being built
                                                        // StringBuilder more efficient than String
            List<LibraryPatron> patrons;                // List of patrons
            string NL = Environment.NewLine;            // NewLine shortcut

            patrons = _lib.GetPatronsList();

            result.Append($"Patron List - {patrons.Count} patrons{NL}{NL}");

            foreach (LibraryPatron p in patrons)
                result.Append($"{p}{NL}{NL}");

            reportTxt.Text = result.ToString();

            // Put cursor at start of report
            reportTxt.SelectionStart = 0;
        }

        // Precondition:  Report, Item List menu item activated
        // Postcondition: The list of items is displayed in the reportTxt
        //                text box
        private void itemListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report being built
                                                        // StringBuilder more efficient than String
            List<LibraryItem> items;                    // List of library items
            string NL = Environment.NewLine;            // NewLine shortcut

            items = _lib.GetItemsList();

            result.Append($"Item List - {items.Count} items{NL}{NL}");

            foreach (LibraryItem item in items)
                result.Append($"{item}{NL}{NL}");

            reportTxt.Text = result.ToString();

            // Put cursor at start of report
            reportTxt.SelectionStart = 0;
        }

        // Precondition:  Report, Checked Out Items menu item activated
        // Postcondition: The list of checked out items is displayed in the
        //                reportTxt text box
        private void checkedOutItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report being built
                                                        // StringBuilder more efficient than String
            List<LibraryItem> items;                    // List of library items
            string NL = Environment.NewLine;            // NewLine shortcut

            items = _lib.GetItemsList();

            // LINQ: selects checked out items
            var checkedOutItems =
                from item in items
                where item.IsCheckedOut()
                select item;

            result.Append($"Checked Out Items - {checkedOutItems.Count()} items{NL}{NL}");

            foreach (LibraryItem item in checkedOutItems)
                result.Append($"{item}{NL}{NL}");

            reportTxt.Text = result.ToString();

            // Put cursor at start of report
            reportTxt.SelectionStart = 0;
        }

        // Precondition:  Insert, Patron menu item activated
        // Postcondition: The Patron dialog box is displayed. If data entered
        //                are OK, a LibraryPatron is created and added to the library
        private void patronToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PatronForm patronForm = new PatronForm(); // The patron dialog box form

            DialogResult result = patronForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                // Use form's properties to get patron info to send to library
                _lib.AddPatron(patronForm.PatronName, patronForm.PatronID);
            }

            patronForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        // Precondition:  Insert, Book menu item activated
        // Postcondition: The Book dialog box is displayed. If data entered
        //                are OK, a LibraryBook is created and added to the library
        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookForm bookForm = new BookForm(); // The book dialog box form

            DialogResult result = bookForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                try
                {
                    // Use form's properties to get book info to send to library
                    _lib.AddLibraryBook(bookForm.ItemTitle, bookForm.ItemPublisher, int.Parse(bookForm.ItemCopyrightYear),
                        int.Parse(bookForm.ItemLoanPeriod), bookForm.ItemCallNumber, bookForm.BookAuthor);
                }

                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Book Validation!", "Validation Error");
                }
            }

            bookForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        // Precondition:  Item, Check Out menu item activated
        // Postcondition: The Checkout dialog box is displayed. If data entered
        //                are OK, an item is checked out from the library by a patron
        private void checkOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Extra Credit - Only display items that aren't already checked out

            List<LibraryItem> notCheckedOutList; // List of items not checked out
            List<int> notCheckedOutIndices;      // List of index values of items not checked out
            List<LibraryItem> items;             // List of library items
            List<LibraryPatron> patrons;         // List of patrons

            items = _lib.GetItemsList();
            patrons = _lib.GetPatronsList();
            notCheckedOutList = new List<LibraryItem>();
            notCheckedOutIndices = new List<int>();

            for (int i = 0; i < items.Count(); ++i)
                if (!items[i].IsCheckedOut()) // Not checked out
                {
                    notCheckedOutList.Add(items[i]);
                    notCheckedOutIndices.Add(i);
                }

            if ((notCheckedOutList.Count() == 0) || (patrons.Count() == 0)) // Must have items and patrons
                MessageBox.Show("Must have items and patrons to check out!", "Check Out Error");
            else
            {
                CheckoutForm checkoutForm = new CheckoutForm(notCheckedOutList, patrons); // The check out dialog box form

                DialogResult result = checkoutForm.ShowDialog(); // Show form as dialog and store result

                if (result == DialogResult.OK) // Only add if OK
                {
                    try
                    {
                        int itemIndex; // Index of item from full list of items

                        itemIndex = notCheckedOutIndices[checkoutForm.ItemIndex]; // Look up index from full list
                        _lib.CheckOut(itemIndex, checkoutForm.PatronIndex);
                    }
                    catch (ArgumentOutOfRangeException) // This should never happen
                    {
                        MessageBox.Show("Problem with Check Out Index!", "Check Out Error");
                    }
                }

                checkoutForm.Dispose(); // Good .NET practice - will get garbage collected anyway
            }
        }

        // Precondition:  Item, Return menu item activated
        // Postcondition: The Return dialog box is displayed. If data entered
        //                are OK, an item is returned to the library
        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Extra Credit - Only display items that are already checked out

            List<LibraryItem> checkedOutList; // List of items checked out
            List<int> checkedOutIndices;      // List of index values of items checked out
            List<LibraryItem> items;     // List of library items

            items = _lib.GetItemsList();
            checkedOutList = new List<LibraryItem>();
            checkedOutIndices = new List<int>();

            for (int i = 0; i < items.Count(); ++i)
                if (items[i].IsCheckedOut()) // Checked out
                {
                    checkedOutList.Add(items[i]);
                    checkedOutIndices.Add(i);
                }

            if ((checkedOutList.Count() == 0)) // Must have checked out items
                MessageBox.Show("Must have items to return!", "Return Error");
            else
            {
                ReturnForm returnForm = new ReturnForm(checkedOutList); // The return dialog box form

                DialogResult result = returnForm.ShowDialog(); // Show form as dialog and store result

                if (result == DialogResult.OK) // Only add if OK
                {
                    try
                    {
                        int itemIndex; // Index of item from full list of items

                        itemIndex = checkedOutIndices[returnForm.ItemIndex]; // Look up index from full list
                        _lib.ReturnToShelf(itemIndex);
                    }
                    catch (ArgumentOutOfRangeException) // This should never happen
                    {
                        MessageBox.Show("Problem with Return Index!", "Return Error");
                    }
                }

                returnForm.Dispose(); // Good .NET practice - will get garbage collected anyway
            }
        }

        // Precondition:    Click File > Open Library, (p. 725)
        // Postcondition:   Library file is loaded and populated
        private void openLibraryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // create and show dialog box enabling user to open file
            DialogResult result;
            string fileName;        // name of file to save data

            using (OpenFileDialog fileSaver = new OpenFileDialog())
            {
                result = fileSaver.ShowDialog();
                fileName = fileSaver.FileName;          // get specified file name
            }

            // ensure user clicked "OK"
            if (result == DialogResult.OK)
            {
                _lib = null;        // delete current library

                // show error if user specified invalid file
                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    try
                    {
                        // create FileStream to obtain read access to file
                        input = new FileStream(fileName, FileMode.Open, FileAccess.Read);

                        _lib = (Library)reader.Deserialize(input);      // desterialize
                        patrons = _lib._patrons;                        // load and display patron info from file
                        items = _lib._items;                            // load and display item info from file

                        // close
                        input.Close();
                    }

                    catch (SerializationException)
                    {
                        // notify user if serialization exception
                        MessageBox.Show("Error! Invalid!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // Precondition:    Click File > Save Library, (p. 722)
        // Postcondition:   Library saved to file
        private void saveLibraryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // create and show dialog box enabling user to save file
            DialogResult result;
            string fileName;        // name of file to save data

            using (SaveFileDialog fileSaver = new SaveFileDialog())
            {
                fileSaver.CheckFileExists = false;      // let user creat file

                // retrieve the result of the dialog box
                result = fileSaver.ShowDialog();
                fileName = fileSaver.FileName;          // get specified file name
            }

            // ensure user clicked "OK"
            if (result == DialogResult.OK)
            {
                // show error if user specified invalid file
                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    // save file via FileStream if user specified valid file
                    try
                    {
                        // open file with write access
                        output = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write);
                        
                        // write library to file
                        formatter.Serialize(output, _lib);
                        
                        // close
                        output.Close();
                    }

                    catch (IOException)
                    {
                        // notify user if file could not be opened
                        MessageBox.Show("Error opening file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // Precondition:    Click Edit > Patron
        // Postcondition:   Patron is loaded and updated
        private void patronToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PatronEditForm selectedPatron = new PatronEditForm(patrons);         
            DialogResult selectResult = selectedPatron.ShowDialog();

            if (selectResult == DialogResult.OK)
            {
                PatronForm patronForm = new PatronForm();

                try
                {
                    // populate selected patron fields
                    patronForm.PatronName = patrons[selectedPatron.PatronIndex].PatronName;
                    patronForm.PatronID = patrons[selectedPatron.PatronIndex].PatronID;
                }
                
                catch
                {
                    MessageBox.Show("Must select book!!!!!!!!", "Error");
                }

                // display parton form
                DialogResult result = patronForm.ShowDialog();

                if (result == DialogResult.OK)
                {
                    patrons.RemoveAt(selectedPatron.PatronIndex);   // delete original
                    LibraryPatron newPatron = new LibraryPatron(patronForm.PatronName, patronForm.PatronID);    // replace patron info
                    patrons.Add(newPatron);                         // save updated patron
                    
                    selectedPatron.Dispose();
                }

                if (result == DialogResult.Cancel)
                {
                    this.DialogResult = DialogResult.Cancel;
                }
            }
        }

        // Precondition:    Click Edit > Book
        // Postcondition:   Book edited and updated
        private void bookToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            BookEditForm selectedBook = new BookEditForm();
            DialogResult selectResult = selectedBook.ShowDialog();

            if (selectResult == DialogResult.OK)
            {
                BookForm bookForm = new BookForm();

                try
                {
                    // populate selected book fields
                    bookForm.ItemTitle = items[selectedBook.BookIndex].Title;
                    bookForm.ItemPublisher = items[selectedBook.BookIndex].Publisher;
                    bookForm.ItemCopyrightYear = Convert.ToString(items[selectedBook.BookIndex].CopyrightYear);
                    bookForm.ItemLoanPeriod = Convert.ToString(items[selectedBook.BookIndex].LoanPeriod);
                    bookForm.ItemCallNumber = items[selectedBook.BookIndex].CallNumber;
                    bookForm.BookAuthor = ((LibraryBook)items[selectedBook.BookIndex]).Author;
                }

                catch
                {
                    MessageBox.Show("Must select book!!!!!!!!", "Error");
                }
                
                // display book form
                DialogResult result = bookForm.ShowDialog();

                if (result == DialogResult.OK)
                {
                    items.RemoveAt(selectedBook.BookIndex);             // delete original
                    LibraryBook newBook = new LibraryBook(bookForm.ItemTitle, bookForm.ItemPublisher, 
                    int.Parse(bookForm.ItemCopyrightYear), int.Parse(bookForm.ItemLoanPeriod),
                    bookForm.ItemCallNumber, bookForm.BookAuthor);      // replace book info
                    items.Add(newBook);                                 // save updated patron

                    selectedBook.Dispose();
                }

                if (result == DialogResult.Cancel)
                {
                    this.DialogResult = DialogResult.Cancel;
                }
            }
        }
    }
}
