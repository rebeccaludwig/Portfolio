﻿// Program 3
// CIS 200-01
// Due: 4/3/2017
// By: D1474

// File: PatronEditForm.cs
// This class selects patron from list to be edited

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class PatronEditForm : Form
    {
        private List<LibraryPatron> patrons;                // List of patrons
        private int selectPatron;                           // moves to correct index

        // Precondition:    Click Edit > Patron
        // Postcondition:   Edit Patron form loaded
        public PatronEditForm()
        {
            InitializeComponent();
            patrons = new List<LibraryPatron>();
        }

        // Precondition:    None
        // Postcondition:   Set values from list
        public PatronEditForm(List<LibraryPatron> patronList)
        {
            InitializeComponent();//init the form
            patrons = patronList;//set the list
            PatronIndex = selectPatron;//set the index value
        }

        // Precondition:    None
        // Postcondition:   Return selected patron by index
        public int PatronIndex
        {
            get
            {
                return patronCbo.SelectedIndex;
            }

            set
            {
                selectPatron = value;
            }
        }

        // Precondition:    form loaded
        // Postcondion:     patrons loaded into combobox
        private void PatronEditForm_Load(object sender, EventArgs e)
        {
            foreach (LibraryPatron patron in patrons)
                patronCbo.Items.Add(patron.PatronName);
        }
        
        // Precondition:    Click OK
        // Postcondition:   Patron index set
        private void okBtn_Click(object sender, EventArgs e)
        {
            int selectPatron = patronCbo.SelectedIndex;
        }
        
        // Precondition:    Click Cancel
        // Postcondtion:    Edit dialog box closed and canceled
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
