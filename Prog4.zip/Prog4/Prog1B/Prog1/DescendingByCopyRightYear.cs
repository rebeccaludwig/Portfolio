﻿// Program 4
// CIS 200-01
// Due: 4/19/2017
// By: D1474

// File: DecendingByCopyRightYear.cs
// By: D1474
// This class provides an IComparer of the LibraryItem class that orders the objects in decending order by copy right year.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    class DescendingByCopyRightYear : Comparer<LibraryItem>
    {
        // Precondition:  None
        // Postcondion:   Reverses natural order.
        //                When i1 < i2, method returns positive #.
        //                When i1 == i2, method returns zero.
        //                When i1 > i2, method returns positive #.
        public override int Compare(LibraryItem i1, LibraryItem i2)
        {
            if (i1 == null && i2 == null)
                return 0;

            if (i1 == null)
                return -1;

            if (i2 == null)
                return 1;

            return (-1) * i1.CopyrightYear.CompareTo(i2.CopyrightYear);
        }
    }
}
